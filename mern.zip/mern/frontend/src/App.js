import { Outlet } from 'react-router-dom';
import './App.css';
import Header from './Component/Header';
import Footer from './Component/Footer';
import { ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useEffect,useState } from 'react';
import SummaryApi from './Common/Commonindex';
import Context from './Context/Contextindex';
import { useDispatch } from 'react-redux';
import { setUserDetails } from './Store/UserSlice';

function App() {
  const [cartProductCount,setCartProductCount]  = useState(0);
  const dispatch = useDispatch()
  const fetchUserDetails = async()=>{
    const dataResponse = await fetch("http://localhost:8080/api/user-details",{
      method : SummaryApi.current_user.method,
      credentials : 'include'
    })
    const dataApi = await dataResponse.json()
    // console.log("data-user",dataApi);
    
    if(dataApi.success){
      dispatch(setUserDetails(dataApi.data))
    }
  }
  const fetchUserAddToCart =async ()=>{
    const dataResponse = await fetch(SummaryApi.addToCartProductCount.url,{
      method : SummaryApi.addToCartProductCount.method,
      credentials : 'include'
    })
    const dataApi = await dataResponse.json()
    console.log("dataApi",dataApi);
    setCartProductCount(dataApi.data?.count)
    

  }
  useEffect(()=>{
    // user-details
    fetchUserDetails() 
    // user-cart product
    fetchUserAddToCart()
  })
  // console.log("fetchUserDetails",fetchUserDetails);
  return (
    <>
    <Context.Provider value={{
      fetchUserDetails,//user details fetch
      cartProductCount, //current user add to cart count
      fetchUserAddToCart
    }}>
    <ToastContainer position='top-right' />
    <Header/>
    <main className='min-h-[clac(100vh-120px)]'>
      <Outlet/>
    </main>
    <Footer/>
    </Context.Provider>
    </>
  );
}

export default App;
