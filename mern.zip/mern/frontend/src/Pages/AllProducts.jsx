import React, { useState, useEffect } from "react";
import UploadProduct from "../Component/UploadProduct";
import SummaryApi from "../Common/Commonindex";
import AdminProductCard from "../Component/AdminProductCard";

const AllProducts = () => {
  const [openUploadProduct, setopenUploadProduct] = useState(false);
  const [allProduct, setAllProduct] = useState([]);

  const fetchAllProduct = async () => {
    const response = await fetch(SummaryApi.allProduct.url);
    const dataResponse = await response.json();
    console.log("product data", dataResponse);

    setAllProduct(dataResponse?.data || []);
  };
  useEffect(() => {
    fetchAllProduct();
  }, []);
  return (
    <div>
      <div className="bg-white py-2 pt-20 px-4 flex justify-between  items-center">
        <h2 className="font-bold text-lg">AllProducts</h2>
        <button
          className=" border py-1 px-3 border-red-600 hover:bg-red-800 hover:text-white transition-all rounded-full "
          onClick={() => setopenUploadProduct(true)}
        >
          upload Product
        </button>
      </div>

      {/**all product */}
      <div className="flex items-center flex-wrap gap-4 py-4  overflow-y-scroll ">
        {allProduct.map((product, index) => {
          return <AdminProductCard data={product} key={index + "allProduct"} fetchdata={fetchAllProduct}/>;
        })}
      </div>
      {/* -------------------uploaad products----------------- */}
      {openUploadProduct && (
        <UploadProduct onClose={() => setopenUploadProduct(false)} fetchData={fetchAllProduct}/>
      )}
    </div>
  );
};

export default AllProducts;
