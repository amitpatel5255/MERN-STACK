import { createBrowserRouter } from "react-router-dom";
import App from "../App";
import Home from "../Pages/Home"
import Login from "../Pages/Login";
import Signup from '../Pages/Signup';
import AdminPanel from '../Pages/AdminPanel'
import Forgotpassword from "../Pages/Forgotpassword";
import AllProducts from "../Pages/AllProducts";
import AllUsers from '../Pages/AllUsers'
import CategoryProduct from "../Pages/CategoryProduct";
import ProductDetails from '../Pages/ProductDetails';
import Cart from "../Pages/Cart";
import SearchProduct from "../Pages/SearchProduct";
const router = createBrowserRouter([
    {
        path:"/",
        element:<App/>,
        children:[
            {path:"",
            element:<Home/> 
            },
            {
                path:"login",
                element:<Login/>
            },
            {
                path:"Forgotpassword",
                element:<Forgotpassword/>
            },
            {
                path:"Signup",
                element:<Signup/>
            },
            {
                path:"product-category",
                element:<CategoryProduct/>
            },
            {
                path:"product/:id" ,
                element:<ProductDetails />
            },
            {
                path:"cart",
                element:<Cart/>
            },
            {
                path:"search",
                element:<SearchProduct/>
            },
            {
                path:"admin-panel",
                element:<AdminPanel/>,
                children:[
                    {
                        path:"all-users",
                        element:<AllUsers/>
                    },
                    {
                        path:"all-products",
                        element:<AllProducts/>
                    }
                ]
            }
        ]
    }
])
export default router