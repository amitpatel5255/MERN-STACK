// const url = "https://api.cloudinary.com/v1_1/djfko1vzz/image/upload"

const uploadImage = async (image)=>{
    const formData = new FormData()
    formData.append("file",image)
    formData.append("upload_preset","mern_product")

    const dataResponse = await fetch("https://api.cloudinary.com/v1_1/djfko1vzz/image/upload",{
        method:"post",
        body:formData
    })
     return dataResponse.json()

}
export default uploadImage